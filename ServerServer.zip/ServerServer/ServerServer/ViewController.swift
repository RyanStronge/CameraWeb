//
//  ViewController.swift
//  ServerServer
//
//  Created by Ryan Stronge on 12/03/2020.
//  Copyright © 2020 Ryan Stronge. All rights reserved.
//

import UIKit
import Swifter
import Dispatch
import AVFoundation
import Luminous
import Foundation

extension UIView{
    func asImage() -> UIImage{
        if #available(iOS 10.0, *) {
                   let renderer = UIGraphicsImageRenderer(bounds: bounds)
                   return renderer.image { rendererContext in
                       layer.render(in: rendererContext.cgContext)
                   }
               } else {
                   UIGraphicsBeginImageContext(self.frame.size)
                   self.layer.render(in:UIGraphicsGetCurrentContext()!)
                   let image = UIGraphicsGetImageFromCurrentImageContext()
                   UIGraphicsEndImageContext()
                   return UIImage(cgImage: image!.cgImage!)
               }
   
    }
}

extension ViewController : AVCapturePhotoCaptureDelegate{
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        guard let imageData = photo.fileDataRepresentation() else{
            return
        }
        let capturedImage = UIImage.init(data: imageData, scale: 1.0)
        if let image = capturedImage{
            UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
            print("image saved status:")
            print(self.saveImage(image: image))
            print("exists in delegate: ")
            print(self.doesExist(fileName: "img.png"))
        }
    }
}

extension UIImage{
    func toBase64(image: UIImage) -> String? {
        //guard let imageData = self.pngData() else { return nil }
        //let base64 = imageData.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters)
        let strBase64 = image.pngData()?.base64EncodedString(options: .lineLength64Characters)
        return strBase64!
    }
}


class ViewController: UIViewController {
    @IBOutlet weak var cameraView: UIView!
    var captureSession: AVCaptureSession?
    var videoPreviewLayer: AVCaptureVideoPreviewLayer?
    var backCamera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
    var capturePhotoOutput: AVCapturePhotoOutput?
    let server = HttpServer()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if #available(iOS 10.2, *){
            let captureDevice = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
            do{
                let input = try AVCaptureDeviceInput(device: captureDevice!)
                captureSession = AVCaptureSession()
                captureSession?.addInput(input)
                videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession!)
                videoPreviewLayer?.frame = view.layer.bounds
                cameraView.layer.addSublayer(videoPreviewLayer!)
                captureSession?.startRunning()
            }
            catch{
                print(error.localizedDescription)
            }
        }
        
        capturePhotoOutput = AVCapturePhotoOutput()
        capturePhotoOutput?.isHighResolutionCaptureEnabled = true
        captureSession?.addOutput(capturePhotoOutput!)
        
    
    }
    
    func capture(){
        guard let capturePhotoOutput = self.capturePhotoOutput else {
            return
        }
        let photoSettings = AVCapturePhotoSettings()
        photoSettings.isHighResolutionPhotoEnabled = true
        capturePhotoOutput.capturePhoto(with: photoSettings, delegate: self)
    }
    
    func getSavedImage(named: String) -> UIImage? {
        if let dir = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false){
            return UIImage(contentsOfFile: URL(fileURLWithPath: dir.absoluteString).appendingPathComponent(named).path)
        }
        return nil
    }
    
    func doesExist(fileName: String) -> Bool{
        let path = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as String
        let url = NSURL(fileURLWithPath: path)
        if let pathComponent = url.appendingPathComponent(fileName){
            let filePath = pathComponent.path
            let fileManager = FileManager.default
            if fileManager.fileExists(atPath: filePath){
                print("file found")
                return true
            }
            print("file not found")
            return false
        }
        print("file path not available")
        return false
    }
    

    
    func saveImage(image: UIImage) -> Bool{
        guard let data = (image.jpegData(compressionQuality: 1) ?? image.pngData()) else{
            return false
        }
        guard let directory = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false) as NSURL else{
            return false
        }
        do{
            try data.write(to: directory.appendingPathComponent("img.png")!)
            print("file written.")
            return true
        } catch{
            print(error.localizedDescription)
            return false
        }
    }
    
    func deletePhoto(fileName: String) -> Bool{
        if let dir = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false){
            print(dir)
            if let _ = self.getSavedImage(named: fileName){
                //here
                do{
                    let fileManager = FileManager.default
                    let url = try fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                    let realUrl = url.appendingPathComponent(fileName)
                    try fileManager.removeItem(at: realUrl)
                    let successMessage: String = "Removed file at " + String(realUrl.absoluteString)
                    print(successMessage)
                    return true
                }
                catch{
                    print("Error removing file")
                    return false
                }
            }
            else{
                print("Cannot find file specififed in documents directory.")
                return false
            }
            
            
        }else{
            print("Error creating file manager.")
        }
        return false
    }
    
    func refresh() -> Data{
        var jsonData: Data = Data.init()
        let connectedViaWiFi = Luminous.Network.isConnectedViaWiFi
        let connectedViaCellular = Luminous.Network.isConnectedViaCellular
        let currentLanguage = Luminous.Locale.currentLanguage
        let currentTimeZone = Luminous.Locale.currentTimeZone
        let currentTimeZoneName = Luminous.Locale.currentTimeZoneName
        let currentCountry = Luminous.Locale.currentCountry
        let currentCurrency = Luminous.Locale.currentCurrency
        let currentCurrencySymbol = Luminous.Locale.currentCurrencySymbol
        let usesMetricSystem = Luminous.Locale.usesMetricSystem
        let decimalSeparator = Luminous.Locale.decimalSeparator
        let carrier = Luminous.Carrier.name
        let processorsNo = Luminous.Hardware.processorsNumber
        let activeProcessorsNo = Luminous.Hardware.activeProcessorsNumber
        let ram = Luminous.Hardware.physicalMemory()
        let systemName = Luminous.Hardware.systemName
        let systemVersion = Luminous.Hardware.systemVersion
        let bootTime = Luminous.Hardware.bootTime
        let powerModeLow = Luminous.Hardware.isLowPowerModeEnabled
        let device = Luminous.Hardware.Device.current.completeName
        let usedSpace = Luminous.Disk.usedSpace(measureUnit: Luminous.MeasureUnit.megabytes)
        let freeSpace = Luminous.Disk.freeSpace(measureUnit: Luminous.MeasureUnit.megabytes)
        let batteryLevel = Luminous.Battery.level
        let batteryState = Luminous.Battery.state
        


        let dic: [String : AnyObject] = [
            "connectedViaWifi": connectedViaWiFi as AnyObject,
            "connectedViaCellular": connectedViaCellular as AnyObject,
            "language": currentLanguage as AnyObject,
            "timeZone": currentTimeZone.description as AnyObject,
            "timeZoneName": currentTimeZoneName as AnyObject,
            "country": currentCountry as AnyObject,
            "currency": currentCurrency as AnyObject,
            "currencySymbol": currentCurrencySymbol as AnyObject,
            "usesMetricSystem": usesMetricSystem as AnyObject,
            "decimalSeparator": decimalSeparator as AnyObject,
            "carrier": carrier as AnyObject,
            "processorsNo": processorsNo as AnyObject,
            "activeProcessorsNo": activeProcessorsNo as AnyObject,
            "ram": ram as AnyObject,
            "systemName": systemName as AnyObject,
            "systemVersion": systemVersion as AnyObject,
            "bootTime": bootTime as AnyObject,
            "powerModeLow": powerModeLow as AnyObject,
            "device": device as AnyObject,
            "usedSpace": usedSpace as AnyObject,
            "freeSpace": freeSpace as AnyObject,
            "batteryLevel": batteryLevel as AnyObject,
            "batteryState": batteryState.rawValue as AnyObject
            
            ]
        do{
            jsonData = try JSONSerialization.data(withJSONObject: dic, options: [.sortedKeys, .prettyPrinted])
            let fileManager = FileManager.default
            let url = try fileManager.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            let jsonUrl = url.appendingPathComponent("phoneInfo.json")
           
            print(jsonUrl)
            try jsonData.write(to: jsonUrl)
            
            
            
            //read
            let jsonReadData = NSData(contentsOf: jsonUrl)
            
            func getDocumentsDirectory() -> URL {
                let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
                return paths[0]
            }
            
            if let jsonReadData = jsonReadData{
                let parsedGames = try JSONSerialization.jsonObject(with: jsonReadData as Data, options: .mutableContainers)
                print(parsedGames)
                print(String(decoding: jsonData, as: UTF8.self))
               /* if let data = pngImage?.pngData(){
                    let filename = getDocumentsDirectory().appendingPathComponent("copy.png")
                    try? data.write(to:filename)
                    print(filename)
                }
                else{
                    print("png error")
                }*/
                
                        
            }
            
        }
        catch{
            print("JSON error")
        }
        return jsonData
    }
    
    func takeView(){
       /* DispatchQueue.main.sync {
            let _: Data = self.refresh()
 
          
            
            //let cameraroll = image?.asImage()
            if(self.doesExist(fileName: "snapshot.png")){
                var _ = self.deletePhoto(fileName: "snapshot.png")
            }
            if(self.saveImage(image: cameraroll)){
                print("Saved Image")
            }
            else{
                print("Failed saving image.")
            }
            print("Should be taken now VVV")
            print(self.doesExist(fileName: "snapshot.png"))*/

           
            
                /*UIGraphicsBeginImageContextWithOptions(image.frame.size, false, 0.0)
                image.layer.render(in: UIGraphicsGetCurrentContext()!)
                let viewImage = UIGraphicsGetImageFromCurrentImageContext()!
                UIGraphicsEndImageContext()
                let data = viewImage.pngData()
                let documentsDir = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
                let writePath = NSURL(fileURLWithPath: documentsDir).appendingPathComponent("snapshot.png")!
                do{
                    try data?.write(to: writePath)
                    print("Written uiview.")

                }catch{
                    print("WRITE ERROR")
                }*/
       // }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        super.viewDidAppear(animated)
        do{
            server["/"] =  { request in
                let data: Data = self.refresh()
                return HttpResponse.ok(.text(String(decoding: data, as: UTF8.self)))
              }
            self.server["/img"] = { request in
                if(self.doesExist(fileName: "img.png")){
                    if(self.deletePhoto(fileName: "img.png")){
                        print("Successfully Deleted File")
                    }
                    else{
                        print("Error Deleting File")
                    }
                }
                self.capture()
                while(self.doesExist(fileName: "img.png")==false){
                    usleep(10000)
                }
                print("should be exists now")
                print(self.doesExist(fileName: "img.png"))
                if let i = self.getSavedImage(named: "img.png"){
                    print("\n\nData:")
                    
            
                    print("Data done\n\n")
                    let data: Data = i.pngData()!
                    return HttpResponse.ok(.data(data))
                }
                return HttpResponse.ok(.text("Image Error"))
            }
            
            try server.start(8080)
            print("Server started.")
        }
        catch{
            print("Server start error.")
        }
    }
    
    }

    
    



